
public class Test3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Commercial C = new Commercial("titi","tata","Present");
		
		System.out.println(C);
		

	}

}
