
public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personne P = new Personne("Clinton","Bill");
Client Cl = new Client("Vargas","Jos�","Cansii");
Commercial Co = new Commercial("Vargas","Jos�","ABSENT");
System.out.println(P);
System.out.println(Co);
System.out.println(Cl);
	}

}
