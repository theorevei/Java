
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Personne P = new Personne("Reveillard", "Th�o");
System.out.println(P);
	}

}
